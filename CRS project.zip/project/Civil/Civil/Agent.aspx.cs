﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Threading;

namespace Civil
{
    public partial class Agent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=DESKTOP-6JEK9PU;Initial Catalog=civil;Integrated Security=True";
                con.Open();
                string rqy = "select * from agentcreate where Name='" + TextBox1.Text + "' and Password='" + TextBox2.Text + "' and LOW='" + DropDownList1.SelectedValue + "'";
                SqlCommand cmd = new SqlCommand(rqy, con);
                SqlDataReader sqr = cmd.ExecuteReader();

                if (sqr.Read())
                {
                    string role = DropDownList1.SelectedValue;
                    Session["username"] = TextBox1.Text;
                    if (role == "Chennai")
                    {
                        Response.Redirect("chennai.aspx");
                    }
                    else if (role == "Cuddalore")
                    {
                        Response.Redirect("cuddalore.aspx");

                    }
                    else if (role == "Villupuram")
                    {
                        Response.Redirect("villupuram.aspx");
                    }
                    else if (role == "Trichy")
                    {
                        Response.Redirect("trichy.aspx");
                    }
                    else if (role == "Tanjore")
                    {
                        Response.Redirect("tanjore.aspx");
                    }
                    else if (role == "Vellore")
                    {
                        Response.Redirect("vellore.aspx");
                    }
                }
                else
                {
                    Response.Write("<script>alert('Username & Password Not Correct')</script>");
                }
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
namespace Civil
{
    public partial class vebirth : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!Page.IsPostBack)
            {
                string ss = "Waiting";
                string lo = "Vellore";
                SqlDataSource2.SelectCommand = "SELECT * from birth where status='" + ss + "' and Location='" + lo + "' ";
                GridView2.DataSourceID = null;
                GridView2.DataSource = SqlDataSource2;
                GridView2.DataBind();
            }
        }
        protected void Chk_CheckedChanged(object sender, EventArgs e)
        {
            int rowid = ((GridViewRow)(sender as Control).NamingContainer).RowIndex;
            TextBox1.Text = GridView2.Rows[rowid].Cells[10].Text;
            TextBox2.Text = GridView2.Rows[rowid].Cells[1].Text;
            TextBox3.Text = GridView2.Rows[rowid].Cells[9].Text;

        }
        void mailapp()
        {
            String user = "jevag72295@gmail.com";
            String pwd = "ukonlewrzodyawmb";

            String to = TextBox3.Text;
            String cont = "Hi " + ",\n" + "Your Request has been Approved. \n\nRegards,\nAdmin Team";
            try
            {
                SmtpClient c = new SmtpClient("smtp.gmail.com", 587);
                c.EnableSsl = true;
                c.DeliveryMethod = SmtpDeliveryMethod.Network;
                c.UseDefaultCredentials = false;
                c.Credentials = new NetworkCredential(user, pwd);
                MailMessage mmsg = new MailMessage();
                mmsg.To.Add(to);
                mmsg.From = new MailAddress(user);
                mmsg.Subject = "Request Status";
                mmsg.Body = cont;
                c.Send(mmsg);
                Response.Write("<script>alert('Sending Successfully')</script>");

            }
            catch (Exception Ex)
            {
                Response.Write("Sending fail" + Ex.Message);
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string sss = "Approved";
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            con.ConnectionString = "Data Source=DESKTOP-6JEK9PU;Initial Catalog=civil;Integrated Security=True";
            con.Open();
            cmd.CommandText = "Update birth set status='" + sss + "' where Regno='" + TextBox2.Text + "' ";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            mailapp();
            Response.Write("<script>alert('Approved Successfully')</script>");
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session.Remove("user_name");
            Session.RemoveAll();
            Response.Redirect("WebForm1.aspx");
        }
    }
}
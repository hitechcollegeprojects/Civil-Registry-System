﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

namespace Civil
{
    public partial class villupuram : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
            if (!Page.IsPostBack)
            {
                string ss = "Waiting";
                string lo = "Villupuram";
                sqlsrc.SelectCommand = "SELECT * from adhar where status='" + ss + "' and LOW='" + lo + "' ";
                GridView1.DataSourceID = null;
                GridView1.DataSource = sqlsrc;
                GridView1.DataBind();
            }

        }
        protected void Chk_CheckedChanged(object sender, EventArgs e)
        {
            int rowid = ((GridViewRow)(sender as Control).NamingContainer).RowIndex;
            TextBox1.Text = GridView1.Rows[rowid].Cells[12].Text;
            TextBox2.Text = GridView1.Rows[rowid].Cells[1].Text;
            TextBox3.Text = GridView1.Rows[rowid].Cells[6].Text;

        }

        protected void Button3_Click(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
               server control at run time. */
        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);
        }

        void mailapp()
        {
            String user = "jevag72295@gmail.com";
            String pwd = "ukonlewrzodyawmb";

            String to = TextBox3.Text;
            String cont = "Hi " + ",\n" + "Your Request has been Approved. \n\nRegards,\nAdmin Team";
            try
            {
                SmtpClient c = new SmtpClient("smtp.gmail.com", 587);
                c.EnableSsl = true;
                c.DeliveryMethod = SmtpDeliveryMethod.Network;
                c.UseDefaultCredentials = false;
                c.Credentials = new NetworkCredential(user, pwd);
                MailMessage mmsg = new MailMessage();
                mmsg.To.Add(to);
                mmsg.From = new MailAddress(user);
                mmsg.Subject = "Request Status";
                mmsg.Body = cont;
                c.Send(mmsg);
                Response.Write("<script>alert('Sending Successfully')</script>");

            }
            catch (Exception Ex)
            {
                Response.Write("Sending fail" + Ex.Message);
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string sss = "Approved";
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            con.ConnectionString = "Data Source=DESKTOP-6JEK9PU;Initial Catalog=civil;Integrated Security=True";
            con.Open();
            cmd.CommandText = "Update adhar set status='" + sss + "' where Regno='" + TextBox2.Text + "' ";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            mailapp();
            Response.Write("<script>alert('Approved Successfully')</script>");
            Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session.Remove("user_name");
            Session.RemoveAll();
            Response.Redirect("WebForm1.aspx");
        }
    }
}
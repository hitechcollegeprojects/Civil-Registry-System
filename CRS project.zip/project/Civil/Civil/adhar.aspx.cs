﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
namespace Civil
{
    public partial class adhar : System.Web.UI.Page
    {
        string Regno = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null)
            {
                Label12.Text = "Welcome " + Session["user_name"].ToString();
            }
            else
            {
                Response.Redirect("WebForm5.aspx");
            }
            if (!IsPostBack)
            {
                GenerateAutoID();

            }
        }
        private void GenerateAutoID()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-6JEK9PU;Initial Catalog=civil;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("Select Count(Regno) from adhar", con);
            con.Open();
            int i = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            i++;
            TextBox7.Text = Regno + i.ToString();
        }
        void mailapp()
        {
            String user = "jevag72295@gmail.com";
            String pwd = "ukonlewrzodyawmb";

            String to = TextBox8.Text;
            String cont = "Hi " + ",\n" + "Your Request has been Taken. \n\nRegards,\nAdmin Team";
            try
            {
                SmtpClient c = new SmtpClient("smtp.gmail.com", 587);
                c.EnableSsl = true;
                c.DeliveryMethod = SmtpDeliveryMethod.Network;
                c.UseDefaultCredentials = false;
                c.Credentials = new NetworkCredential(user, pwd);
                MailMessage mmsg = new MailMessage();
                mmsg.To.Add(to);
                mmsg.From = new MailAddress(user);
                mmsg.Subject = "Request Status";
                mmsg.Body = cont;
                c.Send(mmsg);
                Response.Write("<script>alert('Sending Successfully')</script>");

            }
            catch (Exception Ex)
            {
                Response.Write("Sending fail" + Ex.Message);
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                string defaultstatus = "Waiting";
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-6JEK9PU;Initial Catalog=civil;Integrated Security=True");             
                con.Open();
                string str= "Insert into adhar values('" + TextBox7.Text + "','" + DropDownList1.SelectedValue + "','" + TextBox1.Text + "','" + DropDownList2.SelectedValue + "','" + TextBox2.Text + "','" + TextBox8.Text + "','" + TextBox3.Text + "','" + TextBox6.Text + "','" + DropDownList3.SelectedValue + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + defaultstatus + "')";
                SqlCommand cmd1 = new SqlCommand(str,con);
                cmd1.ExecuteNonQuery();
                cmd1.Dispose();
                con.Dispose();
                con.Close();
                mailapp();
                Response.Write("<script>alert('Insert successfully')</script>");
                Response.Redirect(HttpContext.Current.Request.Url.ToString(), true);
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";
                TextBox5.Text = "";
                TextBox6.Text = "";
                TextBox7.Text = "";
                TextBox8.Text = "";
                
            }
            catch (Exception x)
            {
                Response.Write(x);
            }
        }
    }
}
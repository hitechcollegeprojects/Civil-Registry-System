﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace Civil
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=DESKTOP-6JEK9PU;Initial Catalog=civil;Integrated Security=True";
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "Insert into Reg(username,email,password) values ('" + TextBox1 .Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "')";
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                con.Dispose();
                Response.Write("<script> alert('Registered successfully')</script>");
                con.Close();
            }
            catch (Exception)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Failed, Please Enter Valid data');", true);
            }

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm5.aspx");
        }
    }
}
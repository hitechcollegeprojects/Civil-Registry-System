﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace Civil
{
    public partial class Panreport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null)
            {
                Label1.Text = "Welcome " + Session["user_name"].ToString();
            }
            else
            {
                Response.Redirect("Admin.aspx");
            }
            if (!Page.IsPostBack)
            {
                string ss = "Approved";
                sqlsrc.SelectCommand = "SELECT * from pan where status='" + ss + "' ";
                GridView1.DataSourceID = null;
                GridView1.DataSource = sqlsrc;
                GridView1.DataBind();

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.AddHeader("content-disposition", "attachment;filename=panreport.xls");
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                GridView1.AllowPaging = false;
                GridView1.RenderControl(hw);
                string style = @"<style>.textmode{mso-number-format:\@;}</style>";
                Response.Write(style);
                Response.Output.Write(sw);
                Response.Flush();
                Response.Clear();
                Response.End();
            }

        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            //  base.VerifyRenderingInServerForm(control);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
namespace Civil
{
    public partial class Agentcreate : System.Web.UI.Page
    {
        string Regno = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GenerateAutoID();

            }
        }

        private void GenerateAutoID()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-6JEK9PU;Initial Catalog=civil;Integrated Security=True");
           
            SqlCommand cmd = new SqlCommand("Select Count(Regno) from agentcreate", con);
            con.Open();
            int i = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            i++;
            TextBox1.Text = Regno + i.ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();

                SqlCommand cmd = new SqlCommand();
                con.ConnectionString = "Data Source=DESKTOP-6JEK9PU;Initial Catalog=civil;Integrated Security=True";
                con.Open();
                cmd.CommandText = "Insert into agentcreate values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + DropDownList2.SelectedValue + "','" + DropDownList1.SelectedValue + "','" + TextBox3.Text + "','" + TextBox4.Text + "')";
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert('Insert successfully')</script>");
                Cleartextbox();
            }
            catch (Exception x)
            {
                Response.Write(x);
            }
        }
        private void Cleartextbox()
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
        }
    }
}
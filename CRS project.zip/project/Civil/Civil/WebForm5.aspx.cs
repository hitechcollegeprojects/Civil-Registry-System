﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Civil
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm2.aspx");
        }
            protected void Button2_Click(object sender, EventArgs e)
            {
            try
            {
                String uid = TextBox1.Text;
                String pass = TextBox2.Text;
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-6JEK9PU;Initial Catalog=civil;Integrated Security=True");
                con.Open();
                string rqy = "select * from Reg where username='" + uid + "' and password='" + pass + "'";
                SqlCommand cmd = new SqlCommand(rqy, con);
                SqlDataReader sqr = cmd.ExecuteReader();
                if (sqr.Read())
                {
                    Session["user_name"] = TextBox1.Text;
                    Response.Redirect("services.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Username & Password Not Correct')</script>");
                }
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            }
    }
}